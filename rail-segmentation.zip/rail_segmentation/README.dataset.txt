# BISMILLAH SKRIPSI ALLAHUAKBAR > 2025-03-18 10:25am
https://universe.roboflow.com/dwi-mib5i/bismillah-skripsi-allahuakbar

Provided by a Roboflow user
License: CC BY 4.0

